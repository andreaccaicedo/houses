/*!
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */

import {Pipe, PipeTransform} from '@angular/core';
import {ApiItemType} from '../interfaces/api-item-type';

@Pipe({
  name: 'adevApiLabel',
  standalone: true,
})
export class ApiLabel implements PipeTransform {
  private readonly shortLabelsMap: Record<ApiItemType, string> = {
    [ApiItemType.BLOCK]: 'B',
    [ApiItemType.CLASS]: 'C',
    [ApiItemType.CONST]: 'K',
    [ApiItemType.DECORATOR]: '@',
    [ApiItemType.DIRECTIVE]: 'D',
    [ApiItemType.ELEMENT]: 'El',
    [ApiItemType.ENUM]: 'E',
    [ApiItemType.FUNCTION]: 'F',
    [ApiItemType.INTERFACE]: 'I',
    [ApiItemType.PIPE]: 'P',
    [ApiItemType.NG_MODULE]: 'M',
    [ApiItemType.TYPE_ALIAS]: 'T',
  };

  private readonly fullLabelsMap: Record<ApiItemType, string> = {
    [ApiItemType.BLOCK]: 'Block',
    [ApiItemType.CLASS]: 'Class',
    [ApiItemType.CONST]: 'Const',
    [ApiItemType.DECORATOR]: 'Decorator',
    [ApiItemType.DIRECTIVE]: 'Directive',
    [ApiItemType.ELEMENT]: 'Element',
    [ApiItemType.ENUM]: 'Enum',
    [ApiItemType.FUNCTION]: 'Function',
    [ApiItemType.INTERFACE]: 'Interface',
    [ApiItemType.PIPE]: 'Pipe',
    [ApiItemType.NG_MODULE]: 'Module',
    [ApiItemType.TYPE_ALIAS]: 'Type Alias',
  };

  transform(value: ApiItemType, labelType: 'short' | 'full'): string {
    return labelType === 'full' ? this.fullLabelsMap[value] : this.shortLabelsMap[value];
  }
}
